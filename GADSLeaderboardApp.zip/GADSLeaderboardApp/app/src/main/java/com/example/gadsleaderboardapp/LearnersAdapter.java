package com.example.gadsleaderboardapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;



import java.util.ArrayList;


public class LearnersAdapter extends RecyclerView.Adapter<LearnersAdapter.BookViewHolder> {

    private LayoutInflater layoutInflater;
    ArrayList<Info> infos;
    public LearnersAdapter(ArrayList<Info> infos) {
        this.infos = infos;
    }
    @Override
    public BookViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.fragment_learning, parent, false);
        return new BookViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Info info = infos.get(position);
        holder.bind(info);
    }

    @Override
    public int getItemCount() {
                return infos.size();
    }


    public class BookViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView tvName;
        TextView tvHours;

        public BookViewHolder(View itemView) {
            super(itemView);

            tvName = (TextView) itemView.findViewById(R.id.tvName);
            tvHours = (TextView) itemView.findViewById(R.id.tvHours);
            itemView.setOnClickListener(this);
        }

        public void bind(Info info) {
            tvName.setText(info.name);

            String students="";
          int i=0;
          for(String student:info.students){
             students+=student;
             i++;
             if(i<info.students.length){
                students+=",";
             }
              tvHours.setText(info.hours);
          }


        }

        @Override
        public void onClick(View view) {

        }
    }
    }
