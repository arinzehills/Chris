package com.example.gadsleaderboardapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.example.gadsleaderboardapp.ui.main.SectionsPagerAdapter;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class LeaderActivity extends AppCompatActivity {
private ProgressBar mloading;
    private RecyclerView rvLearners;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);

        Button btnSubmit=findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LeaderActivity.this, SubmitActivity.class);
                startActivity(intent);
            }
        });
    }


private void init(){


    LearningFragment learningFragment= new LearningFragment();
    FragmentTransaction         fragmentTransaction= getSupportFragmentManager().beginTransaction();
    fragmentTransaction.replace(R.id.learningContent, learningFragment);
    LinearLayoutManager infosLayoutManager =
            new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
    rvLearners.setLayoutManager(infosLayoutManager);


    ArrayList<Info> infos=  ApiUtil.getInfoFromJson();
    String resultString = "";
/*
    LearnersAdapter adapter = new LearnersAdapter(infos);
    rvLearners.setAdapter(adapter);
*/
}
    public class InfoQueryTask extends AsyncTask<URL, Void, String> {

        public LearningFragment learningFragment;

        InfoQueryTask(LearningFragment learningFragment) {
            this.learningFragment = learningFragment;
        }
        @Override
        protected String doInBackground(URL... urls) {
            URL searchURL = urls[0];
            String result = null;
            try {
                result = ApiUtil.getJson(searchURL);
            } catch (IOException e) {
                Log.e("Error", e.getMessage());
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            ;
        }
    }

}