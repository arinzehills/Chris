package com.example.gadsleaderboardapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LeaderBoardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader_board);
    }
}
