package com.example.gadsleaderboardapp;

import android.text.TextUtils;

public class Info {
    public String id;
    public String name;
    public String hours;
    public String skilliq;
    public String [] students;

    public Info(String name,String hours,String skilliq,String id, String[] students) {
        this.id=id;
        this.name = name;
        this.hours=hours;
        this.skilliq=skilliq;
        this.students = students;
    }


}
